<?php
$con=mysqli_connect("localhost", "u165068274_usinddir", "Password@9848", "u165068274_usinddir");
if(mysqli_connect_errno()){
echo "Connection Fail".mysqli_connect_error();
}

  ?>
