<ul class="sidebar navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="dashboard.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-fw fa-folder"></i>
          <span>Directory</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
          <h6 class="dropdown-header">Directory:</h6>
          <a class="dropdown-item" href="add-directory.php">Add Directory</a>
          <a class="dropdown-item" href="manage-directory.php">Manage Directory</a>
          
        </div>
      </li>
     <li class="nav-item dropdown">
        <a class="nav-link" href="search-directory.php" >
          <i class="fas fa-fw fa-search"></i>
          <span>Search Directory</span>
        </a>
        
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-fw fa-folder"></i>
          <span>Directory by Status</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
        <a class="dropdown-item" href="allrecords.php">All Records</a>
        <a class="dropdown-item" href="private.php">Private</a>
          <a class="dropdown-item" href="public.php">Public</a>
          
          
        </div>
      </li>
    </ul>
